Библиотеки, с которым собирал в IDE ARDUINO 1.8.16 2021.09.06
https://www.arduino.cc/en/software/OldSoftwareReleases/

Последние версии Arduino
https://www.arduino.cc/en/software/



ArduinoJson 5.13.5
FastLED 3.5.0
GyverButton 

